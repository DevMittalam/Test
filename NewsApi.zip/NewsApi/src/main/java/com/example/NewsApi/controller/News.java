package com.example.NewsApi.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/event")
public class News {


    ArrayList<Emp> ar=new ArrayList<Emp>();
    @GetMapping("/events/{id}")
    @ResponseBody
    public Object getEmployeesById(@PathVariable int id) {
        for (Emp i : ar)
        {
            if(i.getId()==id)
            {
                return i;

            }
        }
        return new ResponseEntity(HttpStatus.NOT_FOUND);

    }

    @GetMapping("/sort/{sort}")
    @ResponseBody
    public ArrayList<Emp> getSort(@PathVariable String sort) {
        ArrayList<Emp> e=null;
     if(sort.equals("duration")){
          e=(ArrayList<Emp>) ar.stream().sorted(Comparator.comparing(Emp::getDuration)).collect(Collectors.toList());
        return e;
     }
     else if(sort.equals("cost")){
         e=(ArrayList<Emp>) ar.stream().sorted(Comparator.comparing(Emp::getCost)).collect(Collectors.toList());
      return e;
     }
     else
        status();
     return new ArrayList<Emp>();
    }
public Object status(){
        return new ResponseEntity(HttpStatus.NOT_FOUND);
    }
    @PostMapping("/add")
    public void createUser(@RequestBody Emp emp)
    {
//        Emp sevedUser=service.save(user);

        try {
            DBConnection con = new DBConnection();
            con.insert(emp);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

    }



    String show(){
          return "Hello Rahul";
      }
      //@GetMapping("title")


}
