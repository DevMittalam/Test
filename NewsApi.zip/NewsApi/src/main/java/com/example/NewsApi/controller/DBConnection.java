package com.example.NewsApi.controller;



        import java.sql.Connection;
        import java.sql.DriverManager;
        import java.sql.PreparedStatement;
        import java.sql.ResultSet;
        import java.sql.SQLException;
        import java.sql.Statement;
        import java.util.ArrayList;
        import java.util.Collections;
public class DBConnection{
    Connection con;
    static int val=100;
    public DBConnection() throws SQLException
    {
        this.con=getConnection();
    }
    public  Connection getConnection() throws SQLException {
        DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
        String url="jdbc:oracle:thin:@localhost:1521/orcl.iiht.tech";
        String userName="system";
        String password="system";
        con=DriverManager.getConnection(url,userName,password);
        return con;
    }
    public void insert(Emp s) throws SQLException {
        PreparedStatement ps=con.prepareStatement("insert into Employee values(?,?,?,?,?)");
        ps.setInt(1,s.getId());
        ps.setString(2,s.getName());
        ps.setString(3,s.getLocation());
        ps.setInt(4,s.getCost());
        ps.setInt(3,s.getDuration());

        ps.executeUpdate();
        ps.close();
    }
    public boolean check(String name, String pass) throws SQLException
    {
        String s="select * from student_login";
        PreparedStatement ps=con.prepareStatement(s);
        ResultSet set=ps.executeQuery();
        while(set.next())
        {
            if(set.getString(2).equals(name)&&set.getString(3).equals(pass))
                return true;
        }
        return false;
    }

}