package com.example.NewsApi.controller;

public class Emp {
    int id;
    String name;
    String location;
    int duration;

    @Override
    public String toString() {
        return "Emp{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", location='" + location + '\'' +
                ", duration=" + duration +
                ", cost=" + cost +
                '}';
    }

    int cost;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public int getCost() {
        return cost;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }

    public Emp(int id, String name, String location, int duration, int cost) {
        this.id = id;
        this.name = name;
        this.location = location;
        this.duration = duration;
        this.cost = cost;
    }
}
